<div class="twitter-widget">
	
    <a class="twitter-timeline" data-widget-id="375593032344563712"
       data-tweet-limit="1"
       data-dnt="true"
       data-theme="light"
       data-link-color="#000"
       data-screen-name="<?php echo $_GET['account_twitter']; ?>"
       data-aria-polite="assertive"
       data-chrome="noheader nofooter noborders noscrollbar transparent">
        &nbsp;
    </a>

</div>

<script type="text/javascript">
    !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
</script>